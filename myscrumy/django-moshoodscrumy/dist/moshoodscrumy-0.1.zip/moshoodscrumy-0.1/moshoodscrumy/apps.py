from django.apps import AppConfig


class MoshoodscrumyConfig(AppConfig):
    name = 'moshoodscrumy'
