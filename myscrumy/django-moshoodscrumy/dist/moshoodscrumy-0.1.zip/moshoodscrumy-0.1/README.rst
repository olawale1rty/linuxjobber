Linuxjobber Internship Project

This App returns a string when you visit the default url. i.e /
